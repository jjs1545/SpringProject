package com.example.blogReadMale.vo;

public class CommentVo {
	private int no;
	private int post_no;
	private String name;
	private String content;
	private String reg_date;
	
	
	/* getter,setter */
	
	public int getNo() {
		return no;
	}
	public void setNo(int no) {
		this.no = no;
	}
	public int getPost_no() {
		return post_no;
	}
	public void setPost_no(int post_no) {
		this.post_no = post_no;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getReg_date() {
		return reg_date;
	}
	public void setReg_date(String reg_date) {
		this.reg_date = reg_date;
	}
	
	@Override
	public String toString() {
		return "CommentVo [no=" + no + ", post_no=" + post_no + ", name=" + name + ", content=" + content
				+ ", reg_date=" + reg_date + "]";
	}
	
	
	
}
