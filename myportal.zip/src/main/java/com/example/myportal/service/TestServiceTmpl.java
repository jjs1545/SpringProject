package com.example.myportal.service;

import org.springframework.stereotype.Service;

@Service("testService")	//Service 빈 이름 변경 
public class TestServiceTmpl {

}
