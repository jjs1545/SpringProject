/**
 * 블로그  VO
 * 
 * */
package com.example.blogReadMale.vo;

public class BlogVo {
	private long no;
	private int USERS_NO;
	private String title;
	private String logo;

	/*회원, 블로그 테이블 조인*/
	private String name;
	private String id;
	
	/*회원, 블로그 테이블 조인 getter/setter */
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	
	
	/* getter,setter */
	
	public long getNo() {
		return no;
	}
	public void setNo(long no) {
		this.no = no;
	}
	public int getUSERS_NO() {
		return USERS_NO;
	}
	public void setUSERS_NO(int uSERS_NO) {
		USERS_NO = uSERS_NO;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getLogo() {
		return logo;
	}
	public void setLogo(String logo) {
		this.logo = logo;
	}
	
	@Override
	public String toString() {
		return "BlogVO [no=" + no + ", USERS_NO=" + USERS_NO + ", title=" + title + ", logo=" + logo + "]";
	}
	
}
