/**
 * 카테고리 VO
 * 
 * */
package com.example.blogReadMale.vo;

public class CategoryVo {
	private Long no;
	private int blog_no;
	private int post_count;
	private String name;
	private String description;
	private String reg_date;
	
	
	/*join 추가*/
	
	private String title;
	private String content;

	
	/* getter,setter */

	public int getBlog_no() {
		return blog_no;
	}

	public Long getNo() {
		return no;
	}

	public void setNo(Long no) {
		this.no = no;
	}

	public void setBlog_no(int blog_no) {
		this.blog_no = blog_no;
	}
	

	public int getPost_count() {
		return post_count;
	}

	public void setPost_count(int post_count) {
		this.post_count = post_count;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getReg_date() {
		return reg_date;
	}

	public void setReg_date(String reg_date) {
		this.reg_date = reg_date;
	}
	
	@Override
	public String toString() {
		return "CategoryVo [no=" + no + ", blog_no=" + blog_no + ", name=" + name + ", description=" + description
				+ ", reg_date=" + reg_date + "]";
	}


	
	/*join getter setter*/
	
	
	public String getTitle() {
		return title;
	}
	
	public void setTitle(String title) {
		this.title = title;
	}
	
	public String getContent() {
		return content;
	}
	
	public void setContent(String content) {
		this.content = content;
	}
	
	
	
	
	
}
